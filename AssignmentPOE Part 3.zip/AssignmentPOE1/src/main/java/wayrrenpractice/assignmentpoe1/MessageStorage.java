/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;
  import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author User
 */
public class MessageStorage {
  


    public static void storeMessage(String id, String recipient, String message, String hash) {
        String json = "{\n"
                + "\"MessageID\": \"" + id + "\",\n"
                + "\"Recipient\": \"" + recipient + "\",\n"
                + "\"Message\": \"" + message + "\",\n"
                + "\"Hash\": \"" + hash + "\"\n"
                + "}";
        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(json + "\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}


