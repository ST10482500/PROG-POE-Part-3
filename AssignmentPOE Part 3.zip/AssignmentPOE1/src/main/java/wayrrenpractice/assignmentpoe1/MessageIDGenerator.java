/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class MessageIDGenerator {
 public static String generateMessageID(int messageNumber) {
        String id = String.format("%010d", messageNumber);
        if (id.length() > 10) {
            return "Invalid ID: exceeds 10 characters";
        }
        return id;
    }
}

    
    
    
    
    
    
   
    
    
    
    
    
    
    
    
    
    

