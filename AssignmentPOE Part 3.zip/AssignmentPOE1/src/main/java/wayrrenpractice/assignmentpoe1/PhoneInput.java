/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class PhoneInput {
  private String phone;  

public PhoneInput(String phone)
{
this.phone = phone;
}
public boolean isValid(){
return
 phone.startsWith("+27") && phone.length()== 12 && phone.substring(3).matches("\\d{9}");
}
public String getMessage(){
if(isValid()) {
return "Cellphone number is successfully added.";
}else{
return "Cellphone number incorrectly formatted or does not contain international code.";
}
}
public String getPhone(){
return phone;

}
}

