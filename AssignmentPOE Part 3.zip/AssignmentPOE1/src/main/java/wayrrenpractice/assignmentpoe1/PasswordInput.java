/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class PasswordInput {
 private String password;
 
 public PasswordInput (String password){
 this.password = password;   
 }
    
   public boolean isValid() {
  return password.length() >=8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*") && password.matches(".*[!@#$%^&*()_+=<>?/{}~`|\\-].*");
   }
  public String getMessage() {
if(isValid()){
return "Password successfully captured.";
} else{
return "Password is not correctly formatted.Please ensure your password is atleast 8 chracters long, contains a capital letter,a number and a special character.";
}
  }

public String getPassword(){
return password;
}
}
