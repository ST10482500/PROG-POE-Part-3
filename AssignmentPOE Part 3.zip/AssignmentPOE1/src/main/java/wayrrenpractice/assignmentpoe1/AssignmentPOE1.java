/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package wayrrenpractice.assignmentpoe1;
import java.util.Scanner;
import java.util.*;
/**
 *
 * @author User
 */
public class AssignmentPOE1 {

    public static void main(String[] args) {
      
   Scanner scanner = new Scanner(System.in);
    boolean registrationSuccess = false;
    
    String savedUsername = "";
    String savedPassword = "";
    String firstName = "";
    String lastName = "";
    
    while(!registrationSuccess)
    { 
        System.out.println("Enter your first name:");
    firstName = scanner.nextLine();
    
        System.out.println("Enter your last name:");
    lastName = scanner.nextLine();
    
        System.out.println("Enter your Username:");
    savedUsername = scanner.nextLine();
    UserNameinput usernameInput = new UserNameinput(savedUsername);
    
        System.out.println(usernameInput.getMessage());
    
    System.out.println("Enter your Password:");
    savedPassword = scanner.nextLine();
    PasswordInput passwordInput = new PasswordInput(savedPassword);
       
    System.out.println(passwordInput.getMessage());
    
        System.out.println("Enter Cellphone Number:");
    String phone = scanner.nextLine();
    PhoneInput phoneInput= new PhoneInput(phone);
    
        System.out.println(phoneInput.getMessage());
    
    registrationSuccess = usernameInput.isValid()&& passwordInput.isValid() &&phoneInput.isValid();
        System.out.println("----------------------------------");
    }
    //Simulate Login
    boolean loginSuccess = false;
    
    while(!loginSuccess){
    
        System.out.println("Please login below:");
        
        System.out.println("Username:");
        String loginUsername = scanner.nextLine();
        
        System.out.println("Password:");
        String loginPassword = scanner.nextLine();
    
    if(loginUsername.equals(savedUsername) && loginPassword.equals(savedPassword))
    {
    
    
        System.out.println("Welcome " + firstName + " " + lastName + ",it is great to see you again!");
    
   loginSuccess = true;
    }else{
    
        System.out.println("Username or password is incorrect.Please try again.");
    }
        System.out.println("----------------------------------");
    }

      // PART 2: Message processing
        int messageCount = 0;
        boolean running = true;

        while (running) {
            System.out.print("Enter recipient phone number: ");
            String recipient = scanner.nextLine();
            if (!RecipientValidator.isValidRecipient(recipient)) {
                System.out.println("Recipient number is incorrectly formatted. Try again.\n");
                continue;
            }

            System.out.print("Enter your message: ");
            String message = scanner.nextLine();
            String lengthCheck = MessageValidator.isValidLength(message);
            if (!lengthCheck.equals("valid")) {
                System.out.println(lengthCheck);
                continue;
            }

            String messageID = MessageIDGenerator.generateMessageID(messageCount + 1);
            String messageHash = MessageHashGenerator.createMessageHash(message);

            System.out.println("Message ID: " + messageID);
            System.out.println("Message Hash: " + messageHash);

            System.out.println("Select option: 1 - Send, 2 - Store, 3 - Disregard");
            int option = Integer.parseInt(scanner.nextLine());
            MessageOptions.handleMessageOption(option, messageID, recipient, message, messageHash);
            
            if (option == 1) {
                MessageTracker.incrementMessages();
            }

            System.out.println("Total messages sent: " + MessageTracker.getTotalMessages());

            System.out.print("Continue? (y/n): ");
            String cont = scanner.nextLine();
            if (cont.equalsIgnoreCase("n")) {
                running = false;
            }
        }

        System.out.println("\nAll messages this session:");
        MessageList.printMessages();
        System.out.println("Goodbye.");
   }
//Part 3
public class CombinedMessagingApp {

private static final Scanner SC = new Scanner(System.in);
private static final MessageTracker2 TRACKER = new MessageTracker2();
    
public static void main(String[] args){

 TRACKER.populateDeveloperTestData();   
 //main loop   
 boolean running = true;
 while(running){
  printMenu();  
      
 String choice = SC.nextLine().trim();
  switch(choice){     
      case "1"   -> TRACKER.displaySendersAndRecipients();     
      case "2"  ->  TRACKER.displayLongestSentMessage();   
      case "3"  ->  searchByIdFlow();
      case "4"  ->  searchByRecipientFlow();
      case "5"  ->  deleteByHashFlow();
      case "6"  ->  TRACKER.displaySentReport();
      case "7"  ->  {
        running = false;
         System.out.println("Goodbye!");   
      }
      default  ->  System.out.println("Invalid option. Try again.");
      }  
 }
}       
private static void printMenu(){        
    System.out.println("""
                       \n ===== PROG5121 POE - Parts 1-3 =====
                       1.Display sender & recipient of all SENT messages
                       2. Display LONGEST sent message
                       3. Search by MESSAGE ID
                       4. Search for all messages for a RECIPIENT
                       5. Delete STORED message by HASH
                       6. Display full SENT message report
                       7. Exit ----------------------------------------------------------------------""");        
  System.out.println("Choose option: ");      
}   
 private static void searchByIdFlow(){     
   System.out.println("Enter Message ID: ");     
   String id = SC.nextLine();
   TRACKER.searchByMessageID(id).ifPresentOrElse(rec  -> System.out.println(rec.prettyPrint()), ()  -> System.out.println("Message ID not found."));   
 }   
 private static void searchByRecipientFlow(){     
     System.out.println("Enter recipient phone number: ");    
String rec = SC.nextLine();
var list = TRACKER.searchByRecipient(rec);

if(list.isEmpty()){
  System.out.println("No messages for that recipient.");
}else{
list.forEach(r  -> System.out.println("\"" + r.getText() + "\""));
}
 }
private static void deleteByHashFlow(){
 System.out.println("Enter message hash: ");
String hash = SC.nextLine();
TRACKER.deleteByHash(hash).ifPresentOrElse(rec  -> System.out.println("Message \"" + rec.getText() +  "\" successfully deleted."), ()  -> System.out.println("Hash not found(nothing deleted)."));

}
}
}