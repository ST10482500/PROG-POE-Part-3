/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class MessageRecord {
    
public enum Status {SENT, STORED, DISREGARD }

private final String id;
private final String hash;
private final String sender;
private final String recipient;
private final String text;
private final Status status;

public MessageRecord (String id, String hash, String sender, String recipient, String text, Status status ) {

this.id = id;
this.hash = hash;
this.sender = sender;
this.recipient = recipient;
this.text = text;
this.status = status;
}

public String getId()
{ return id; }
public String getHash()
{ return hash; }
public String getSender()
{ return sender; }
public String getRecipient()
{ return recipient; }
public String getText()
{ return text; }
public Status getStatus()
{ return status; }

// formatted view for screen and reports
public String prettyPrint(){
return """
  
------------------------
       ID : %s        
       Hash : %s           
       To : %s  
       Text : "%s"
       Flag : %s  
""".formatted(id, hash, recipient, text, status);

}
}
