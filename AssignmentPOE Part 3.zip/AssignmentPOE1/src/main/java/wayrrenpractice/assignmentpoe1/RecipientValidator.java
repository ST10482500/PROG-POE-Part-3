/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class RecipientValidator {
    public static boolean isValidRecipient(String number) {
        return number.startsWith("+") && number.length() <= 13;
    }

    public static String validateRecipient(String number) {
        if (isValidRecipient(number)) {
            return "Success: Cell phone number successfully captured.";
        } else {
            return "Failure: Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
}


