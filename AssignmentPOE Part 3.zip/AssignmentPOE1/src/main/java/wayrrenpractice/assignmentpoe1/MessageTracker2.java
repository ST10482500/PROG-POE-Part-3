/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;
import java.util.*;
import java.util.stream.*;
/**
 *
 * @author User
 */
public class MessageTracker2 {

//Core arrays for flexability    
private final List<MessageRecord> sent = new ArrayList<>();
private final List<MessageRecord> stored = new ArrayList<>();
private final List<MessageRecord> disregarded = new ArrayList<>();

public void populateDeveloperTestData(){

addSent("+27834557896", "Did you get the cake?");
addStored("+27838884567", "Where are you? You are late! I have asked you to be on time. ");

addDisregarded("+27834484567", "Yohoooo, I am at your gate." );
addSent("08388884567" , "It is dinner time!");
addStored("+278388884567", "OK, I am leaving without you.");
}

public void addSent(String r, String m) { add(r, m, MessageRecord.Status.SENT); }
public void addStored(String r, String m) { add(r, m, MessageRecord.Status.STORED); }
public void addDisregarded(String r, String m) { add(r, m, MessageRecord.Status.DISREGARD); }

public Optional<MessageRecord> searchByMessageID(String id){
return Stream.of(sent, stored,disregarded).flatMap (List::stream ).filter(rec -> rec.getId().equals(id)).findFirst();
}

public List <MessageRecord> searchByRecipient (String recipient ){
 return Stream.concat(sent.stream(), stored.stream()).filter(rec -> rec.getRecipient().equals(recipient)).toList();
}

public Optional <MessageRecord> deleteByHash(String hash){
Iterator<MessageRecord> it = stored.iterator();
while(it.hasNext()){

MessageRecord rec = it.next();
if(rec.getHash().equals(hash)){
it.remove();
return Optional.of((rec));
}
}
return Optional.empty();
}


public void displaySendersAndRecipients(){
if (sent.isEmpty()){
  System.out.println("No sent messages yet. ");
return;
}

sent.forEach(rec -> System.out.println("Sender: " + rec.getSender() + "Recipient " + rec.getRecipient()));
}

public void displayLongestSentMessage(){
sent.stream().max(Comparator.comparingInt(r -> r.getText().length())).ifPresentOrElse(rec -> System.out.println("\" " +rec.getText() + "\""), () -> System.out.println("No messages sent yet."));
}

public void displaySentReport(){
if (sent.isEmpty()){
  System.out.println("No sent messages to report.");
return;
}
  System.out.println("\n------ SENT MESSAGE REPORT -------");
  sent.forEach(rec -> System.out.println("%s | %s | \"%s\"".formatted(rec.getHash(), rec.getRecipient(), rec.getText())));
}

public void loadStoredMessagesFromJson(){
}


public void saveStoredMessagesToJson(){
}


private void add(String recipient, String msg, MessageRecord.Status status){
//validate with helpers

if(! RecipientValidator.isValidRecipient(recipient)) return;

String result = MessageValidator.isValidLength(msg);

if(! result.equals("Valid")){
System.out.println(result);
return;
}
int messageNumber = 1;
String id = MessageIDGenerator.generateMessageID(messageNumber);

String hash = MessageHashGenerator.createMessageHash(msg);

MessageRecord rec = new MessageRecord( id, hash, "Developer", recipient, msg, status);
switch(status){
    case SENT      -> sent.add(rec);
    case STORED     -> stored.add(rec);
    case DISREGARD     -> disregarded.add(rec);


}
}
}



