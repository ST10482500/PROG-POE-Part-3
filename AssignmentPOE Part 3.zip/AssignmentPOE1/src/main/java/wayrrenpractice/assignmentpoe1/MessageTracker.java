/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.assignmentpoe1;

/**
 *
 * @author User
 */
public class MessageTracker {
private static int totalMessages = 0;

    public static void incrementMessages() {
        totalMessages++;
    }

    public static int getTotalMessages() {
        return totalMessages;
    }
}
   

